package com.jotta7.panel;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.View;
import android.view.MotionEvent;
import android.widget.*;

public class FloatingPanelService extends Service {
    WindowManager wm;
    View bubble;
    View panel;
    WindowManager.LayoutParams bubbleParams, panelParams;
    int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density); }

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        bubbleParams = new WindowManager.LayoutParams(dp(58), dp(58), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.LEFT;
        bubbleParams.x = dp(12); bubbleParams.y = dp(180);

        TextView b = new TextView(this);
        b.setText("J7");
        b.setTextColor(Color.WHITE);
        b.setTextSize(17);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setGravity(Gravity.CENTER);
        b.setBackgroundColor(Color.rgb(205, 20, 35));
        bubble = b;
        bubble.setOnClickListener(v -> togglePanel());
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy; int ox, oy; boolean moved;
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    sx=e.getRawX(); sy=e.getRawY(); ox=bubbleParams.x; oy=bubbleParams.y; moved=false; return false;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    float dx=e.getRawX()-sx, dy=e.getRawY()-sy;
                    if (Math.abs(dx)>dp(5)||Math.abs(dy)>dp(5)) moved=true;
                    bubbleParams.x=ox+(int)dx; bubbleParams.y=oy+(int)dy;
                    try { wm.updateViewLayout(bubble,bubbleParams); } catch(Exception ignored) {}
                    return moved;
                }
                return false;
            }
        });
        wm.addView(bubble, bubbleParams);
    }

    void togglePanel() {
        if (panel != null) { try { wm.removeView(panel); } catch(Exception ignored) {} panel=null; return; }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(12), dp(14), dp(12));
        box.setBackgroundColor(Color.rgb(15,15,15));
        TextView title = new TextView(this);
        title.setText("JOTTA'7 PANEL");
        title.setTextColor(Color.rgb(255,55,55));
        title.setTextSize(18);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        box.addView(title);
        TextView info = new TextView(this);
        info.setText("Acceso rápido\n• Sensibilidad: abre la app para editar tus valores\n• Rendimiento: cierra apps que no uses y activa No molestar si quieres");
        info.setTextColor(Color.WHITE);
        info.setTextSize(13);
        info.setPadding(0, dp(10), 0, dp(10));
        box.addView(info);
        Button open = new Button(this);
        open.setText("ABRIR CONFIGURACIÓN");
        open.setOnClickListener(v -> {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        });
        box.addView(open);
        Button close = new Button(this);
        close.setText("CERRAR MENÚ");
        close.setOnClickListener(v -> { try { wm.removeView(panel); } catch(Exception ignored) {} panel=null; });
        box.addView(close);

        panelParams = new WindowManager.LayoutParams(dp(260), -2,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.LEFT;
        panelParams.x = dp(78); panelParams.y = dp(180);
        panel = box;
        wm.addView(panel, panelParams);
    }

    @Override public int onStartCommand(Intent i, int flags, int startId) { return START_STICKY; }
    @Override public void onDestroy() {
        if (panel != null) try { wm.removeView(panel); } catch(Exception ignored) {}
        if (bubble != null) try { wm.removeView(bubble); } catch(Exception ignored) {}
        panel=null; bubble=null;
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
