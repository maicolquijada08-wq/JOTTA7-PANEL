package com.jotta7.panel;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    EditText general, redDot, scope2x, scope4x, sniper;
    LinearLayout root;

    int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(0);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(20));
        root.setBackgroundColor(Color.rgb(12,12,12));

        TextView title = new TextView(this);
        title.setText("JOTTA'7 PANEL");
        title.setTextColor(Color.rgb(255,55,55));
        title.setTextSize(27);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(55)));

        TextView subtitle = new TextView(this);
        subtitle.setText("PANEL PERSONAL • ANDROID");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setTextSize(12);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(30)));

        TextView note = new TextView(this);
        note.setText("Guarda tus ajustes manuales de sensibilidad. Estos valores no cambian Free Fire automáticamente.");
        note.setTextColor(Color.WHITE);
        note.setTextSize(14);
        note.setPadding(0, dp(12), 0, dp(12));
        root.addView(note);

        general = field("General");
        redDot = field("Punto rojo");
        scope2x = field("Mira 2x");
        scope4x = field("Mira 4x");
        sniper = field("Mira francotirador");

        Button save = button("GUARDAR CONFIGURACIÓN");
        save.setOnClickListener(v -> {
            getPreferences(0).edit()
                .putString("general", general.getText().toString())
                .putString("redDot", redDot.getText().toString())
                .putString("scope2x", scope2x.getText().toString())
                .putString("scope4x", scope4x.getText().toString())
                .putString("sniper", sniper.getText().toString()).apply();
            Toast.makeText(this, "Configuración guardada", Toast.LENGTH_SHORT).show();
        });
        root.addView(save, params());

        Button overlay = button("ACTIVAR BOTÓN FLOTANTE");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
                Toast.makeText(this, "Activa el permiso y vuelve a la aplicación.", Toast.LENGTH_LONG).show();
            } else {
                startService(new Intent(this, FloatingPanelService.class));
                Toast.makeText(this, "Botón flotante activado", Toast.LENGTH_SHORT).show();
            }
        });
        root.addView(overlay, params());

        Button stop = button("QUITAR BOTÓN FLOTANTE");
        stop.setOnClickListener(v -> stopService(new Intent(this, FloatingPanelService.class)));
        root.addView(stop, params());

        TextView footer = new TextView(this);
        footer.setText("Herramientas informativas. No modifica el juego ni automatiza disparos.");
        footer.setTextColor(Color.GRAY);
        footer.setTextSize(12);
        footer.setPadding(0, dp(18), 0, 0);
        root.addView(footer);

        setContentView(root);
        loadSaved();
    }

    EditText field(String label) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(14);
        root.addView(tv);
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setHint("Valor manual");
        e.setInputType(2);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.GRAY);
        e.setPadding(dp(12), 0, dp(12), 0);
        e.setBackgroundColor(Color.rgb(35,35,35));
        root.addView(e, new LinearLayout.LayoutParams(-1, dp(46)));
        View spacer = new View(this);
        root.addView(spacer, new LinearLayout.LayoutParams(1, dp(8)));
        return e;
    }

    Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(190,25,35)));
        return b;
    }

    LinearLayout.LayoutParams params() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(50));
        p.setMargins(0, dp(8), 0, dp(4));
        return p;
    }

    void loadSaved() {
        android.content.SharedPreferences p = getPreferences(0);
        general.setText(p.getString("general", ""));
        redDot.setText(p.getString("redDot", ""));
        scope2x.setText(p.getString("scope2x", ""));
        scope4x.setText(p.getString("scope4x", ""));
        sniper.setText(p.getString("sniper", ""));
    }
}
