JOTTA'7 PANEL — proyecto Android inicial

IMPORTANTE:
- Este archivo ZIP contiene el CÓDIGO FUENTE, no un APK ya compilado.
- Es una app independiente para guardar valores manuales de sensibilidad y mostrar un menú flotante.
- No modifica archivos de Free Fire, no automatiza disparos y no promete mejorar la puntería.
- El menú flotante requiere permiso de Android para mostrarse encima de otras aplicaciones.

Cómo intentar compilarlo desde Android:
1. Instala una herramienta de desarrollo Android compatible y de una fuente confiable. AndroidIDE es una opción para compilar proyectos Gradle en el teléfono, pero la compatibilidad depende de la versión de Android y de la herramienta.
2. Extrae este ZIP en el almacenamiento del teléfono.
3. Abre/importa la carpeta JOTTA7_PANEL como proyecto Gradle.
4. Deja que Gradle sincronice y descarga las dependencias oficiales si te lo solicita.
5. Ejecuta la tarea de compilación APK (normalmente :app:assembleDebug).
6. Si compila, el APK de prueba suele quedar en app/build/outputs/apk/debug/app-debug.apk.
7. Instala únicamente el APK que tú mismo compilaste y revisa los permisos antes de concederlos.

Si falla:
- Revisa el mensaje de error y la versión de Java/JDK que pide tu entorno.
- No descargues APKs modificados de páginas desconocidas.
- Este proyecto es una plantilla inicial y puede requerir ajustes según la herramienta de compilación.
